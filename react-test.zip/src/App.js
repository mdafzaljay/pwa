import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      Version 11.0
    </div>
  );
}

export default App;
